---
name: clean-code
description: "Review and guide Laravel code following Bitboss clean code standards (SRP, fat models, PSR12, DRY, Eloquent best practices, naming conventions, etc.)"
allowed-tools: Read, Grep, Glob, Bash
argument-hint: "[path-opzionale]"
---

# Clean Code Review

## Scope

1. Se `$ARGUMENTS` contiene un path, analizza **solo quel path** (ricorsivamente)
2. Altrimenti, esegui `git diff master --name-only --diff-filter=ACMR -- '*.php'` per trovare i file PHP modificati rispetto a `master`
3. Se non ci sono file modificati, comunicalo e termina

Per ogni file nello scope, leggi il contenuto completo e analizza secondo la checklist.

## Checklist

### 1. Single Responsibility Principle (SRP)
- Ogni classe e metodo ha UNA sola responsabilità
- Se un metodo fa più di una cosa, estrarre logica in metodi privati/protetti descrittivi
- Metodi più lunghi di ~20 righe sono un code smell

### 2. Fat Models, Skinny Controllers
- La logica DB appartiene ai modelli Eloquent, scope, o classi Action/Service
- I controller orchestrano: chiamano un service/model, restituiscono una risposta
- Nessuna query builder chain dentro un controller

### 3. Business Logic in Service/Action Classes
- Logica complessa (file handling, chiamate esterne, calcoli) in classi `*Service` o `*Action`
- I controller delegano, non implementano logica direttamente

### 4. Validation in Request Classes
- Mai `$request->validate([...])` inline nel controller
- Sempre classi `*Request` che estendono `FormRequest`

### 5. DRY — Don't Repeat Yourself
- Condizioni di query duplicate → suggerire Eloquent scopes (`scopeActive`, ecc.)
- Frammenti Blade ripetuti → suggerire partial o componenti

### 6. Eloquent over Query Builder / Raw SQL
- Preferire relazioni Eloquent e scopes rispetto a query raw
- `Model::query()` invece di `DB::table()`
- Metodi `Collection` invece di `array_*`

### 7. N+1 Queries
- Nessuna query dentro loop `@foreach` in Blade
- Sempre eager loading: `User::with('profile')->get()`
- Mai `Model::all()` — sempre vincoli o paginazione

### 8. Query Performance
- `User::all()->count()` → `User::count()`
- `foreach(Model::where(...)->get() as $m) { $m->update(...) }` → `Model::where(...)->update([...])`

### 9. PSR-12 Code Style
- Metodi e variabili in camelCase
- Classi in PascalCase
- Indentazione e spaziatura corretta
- Nessun tag di chiusura `?>`

### 10. Laravel Naming Conventions
| Cosa | Convenzione | Esempio |
|------|-------------|---------|
| Controller | Singolare | `ArticleController` |
| Model | Singolare | `User` |
| Route | plurale, kebab-case | `articles/1` |
| Named route | snake_case + dot | `users.show_active` |
| Tabella | plurale, snake_case | `article_comments` |
| Foreign key | `{model}_id` | `article_id` |
| Metodo | camelCase | `getAll` |
| Variabile | camelCase | `$articlesWithAuthor` |
| Trait | aggettivo | `Notifiable` |

### 11. No Magic Numbers / Variabili oscure
- `$a`, `$u`, `$k` → nomi descrittivi
- Stringhe letterali nelle condizioni → costanti o config (`Article::TYPE_NORMAL`)
- Numeri magici → costanti con nome

### 12. Config, non `.env` diretto
- `env('API_KEY')` nel codice → `config('api.key')`
- I valori `.env` si leggono solo dentro `config/*.php`

### 13. Sintassi Laravel concisa
- `$request->session()->get('cart')` → `session('cart')`
- `->orderBy('created_at', 'desc')` → `->latest()`
- `->orderBy('created_at', 'asc')` → `->oldest()`
- `->first()->name` → `->value('name')`
- `Carbon::now()` → `now()`

### 14. IoC / Dependency Injection
- `new Service()` dentro un metodo → iniettare via costruttore o `app(Service::class)`

### 15. No Logic in Routes
- Nessuna closure con business logic nei file route
- Le route mappano solo a metodi dei controller

### 16. No JS/CSS in Blade, No HTML in PHP
- Nessun blocco `<script>` o `<style>` nei template Blade
- Nessun `echo '<div>...'` nelle classi PHP

### 17. Date
- Salvare date in formato standard
- Usare accessors/mutators Eloquent per la formattazione
- Mai formattare date inline con `Carbon::createFromFormat(...)`

### 18. API vs Ajax
- Route API (token-auth, client esterni) → `routes/api.php`
- Route Ajax (session-auth, same-origin) → `routes/web.php`

## Output

Produci un report strutturato:

```
## Review: Clean Code — {data odierna}

### Scope
- Branch: `{branch corrente}` vs `master`
- File analizzati: {N}
- {lista file}

### Critical
- **[file.php:42](path/to/file.php#L42)**: Violazione + regola (#N) + snippet codice + fix suggerito

### Warning
- **[file.php:18](path/to/file.php#L18)**: Violazione + regola (#N) + fix suggerito

### Suggestion
- **[file.php:5](path/to/file.php#L5)**: Miglioramento + regola (#N)

### Summary
- Critical: N | Warning: N | Suggestion: N
- Verdict: Approvato / Da rivedere / Bloccante
```

### Criteri di classificazione

| Livello | Quando usarlo |
|---------|---------------|
| **Critical** | Viola SRP, introduce N+1, business logic nel controller, SQL injection, `$guarded = []` |
| **Warning** | Codice duplicato (DRY), naming non convenzionale, metodo troppo lungo, query non ottimale |
| **Suggestion** | Sintassi semplificabile, commento superfluo, piccolo miglioramento di leggibilità |

Se non ci sono problemi, scrivi "Nessun problema trovato" con il verdict "Approvato".
